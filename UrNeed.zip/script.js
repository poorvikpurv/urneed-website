function showAlert() {
  alert("Welcome to UrNeed! Let's get started.");
}
